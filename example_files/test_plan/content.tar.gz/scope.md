# Scope

## Background

BTB (Broadband to Business) Australia are a company specialising in whitelabling broadband telecommunications services to businesses with existing cusomter bases. They provide the complete range of services required to operate an internet service provider, allowing their customers to focus on the sales and marketing.

They have entered into an agreement with a large energy provider to whitelabel their services, who has specified that their systems be subject to network and web application penetration testing prior to launch.

Core to their offering is a bespoke application called CINDY. CINDY is written in Java, with a mysql database and hosted in an active/active configuration across a datacenter and BTB's Melbourne office. Docker is used as a hosting platform, and a Palo Alto firewall separates the application from the Internet. The following metrics describe the size of CINDY:

* Lines of Java code: 172623
* XML configuration lines: 4023
* Lines of JSP and JS files: 82221
* Number of JSP files (dynamic pages): 117

There are 19 distinct user roles. There are three main profiles "Non Admin", "Limited Admin" or "Full Admin" and then 9 sub-groups which give additional access. The profiles provide the following functions:

* Full Admin - Ability to view most of CINDY functions (including special reports, bureau reports, add journals (credits/debits etc) except for those explicitly granted by the below sub-groups.
* Limited Admin - Extremely cut down version of CINDY which only gives access to non sensitive information about customers with the ability to add notes and change some detail
* Non Admin - Ability to log in, download their current bill and pay the currently issued bill.

Sub-groups are defined below:

* ADMIN - Has access to every additional function in CINDY which the below sub-groups provide
* PROVISIONING - Has access to the MAC (Moves, Adds and Changes) area and the Provisioning area of CINDY.
* CUSTOMER_SERVICE - Provides access to viewing more customer information and limits.
* IT - No explicit additional functionality
* EMAIL_TEMPLATE_ADMIN - ability to add and remove email and SMS templates
* PROV_ADMIN - provides additional functionality in the MAC area
* COLLECTIONS - Ability to write off late payment fees
* BUREAU - Ability to see bureau reports even as a Limited Admin
* BUREAU_STAFF - Ability to view additional customer information

All functions have the ability to upload files in some capacity except for "Non Admin".

%{client}'s services include a call centre located in Manilla and outsourced to Acquire BPO. In order to perform their duties, staff within the contact centre make use of CINDY, a number of other third party cloud based applications, and an ININ (GeneSys) Phone System hosted by %{client}. CINDY and the ININ phone system are whitelisted by the Palo Alto firewall.

## Threat Model

Several threats have been identified as being of interest:

* Attacks via the Manilla office, which is outsourced to Acquire, a company with five to ten thousand employees
* Direct attacks from the broader Internet
* Attacks against the CINDY application

Of particular concern to BTB are attacks that could result in:

* Remote compromise of BTB systems
* Unauthorised disclosure of commercial and/or personally identifiable information
* Fraud or other loss of money

## Activities

The following activities are in-scope for this assessment:

* A kick-off meeting
* An application walkthrough
* A penetration test of CINDY
* A vulnerability assessment of Internet facing infrastructure
* A vulnerability assessment of infrastructure facing the Manilla office
* Delivery of a single report covering all activities above
* Retesting of fixes implemented for vulnerabilies identified during the assessment and confirmation they are effective

## Exclusions

The following activities are out of scope:

* Saltbush will not implement fixes for vulnerabilities identified the assessment
* Denial of service is out of scope
* Social engineering is out of scope
* Any activities not explicitly defined as in-scope is out of scope
