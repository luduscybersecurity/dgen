#Findings and Technical Recommendations 
This section describes findings and recommendations identified by Saltbush during 
testing.  Details on the ranking system can be found in the “[Finding Rating 
Methodology]”.

